package caseStudy.searchMicroservices.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UserServiceImplTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
