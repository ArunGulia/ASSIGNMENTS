package com.caseStudy.checkinMicroService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckinMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
