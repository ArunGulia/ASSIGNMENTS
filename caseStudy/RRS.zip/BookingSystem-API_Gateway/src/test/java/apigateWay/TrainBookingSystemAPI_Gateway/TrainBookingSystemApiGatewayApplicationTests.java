package apigateWay.TrainBookingSystemAPI_Gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainBookingSystemApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
